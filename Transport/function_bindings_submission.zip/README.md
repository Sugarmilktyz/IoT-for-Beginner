# Function Bindings with Azure Functions

This project demonstrates how to configure Azure Function output bindings to Azure Blob Storage.

## Files

- `main.py`: Azure Function that generates a message and returns it.
- `function.json`: Configuration for HTTP trigger and Blob output binding.

## How to Use

1. Deploy this function to your Azure Function App.
2. Set up `AzureWebJobsStorage` in your application settings.
3. Call the function via HTTP and check the blob storage container `samples-output`.

## Outcome

When called, this function will generate a string and store it as a blob in your configured Azure Blob Storage container.
