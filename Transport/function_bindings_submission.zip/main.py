import logging
import azure.functions as func

def main(req: func.HttpRequest) -> func.Out[str]:
    logging.info('Python HTTP trigger function processed a request.')

    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('name')

    message = f"Hello, {name}. This blob was created using Azure Functions!" if name else "This blob was created using Azure Functions!"
    return func.Out(message)
