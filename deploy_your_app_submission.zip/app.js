
const subscriptionKey = "YOUR_SUBSCRIPTION_KEY";
console.log("Subscription key is loaded securely.");
