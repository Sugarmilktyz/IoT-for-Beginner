
# Location Visualizer Web App

This app visualizes location data.

## Deployment

This app is deployed using **Azure Static Web Apps**. The `subscriptionKey` is stored in a secure cloud environment and accessed as a variable.
