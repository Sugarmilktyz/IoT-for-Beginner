# GPS Data Parser Submission

## ✅ What I Did
I investigated additional GPS data from NMEA sentences. Instead of only extracting latitude and longitude, I also extracted:

- Date and time (from `$GPRMC`)
- Speed over ground (from `$GPRMC`)
- Altitude (from `$GPGGA`)
- Number of satellites

## 🧪 How It Works
1. Sample NMEA sentences are parsed.
2. Outputs include:
   - Latitude & Longitude
   - UTC Time & Date
   - Altitude (above sea level)
   - Speed (in knots)

## 🧰 Tools Used
- Python 3
- `pynmea2` library

## 🧾 How to Run
1. Install Python and `pynmea2`:
   ```bash
   pip install pynmea2
   ```

2. Run the script:
   ```bash
   python gps_data_parser.py
   ```
