import pynmea2

# Sample NMEA sentences (normally this would come from a GPS module via serial)
sample_sentences = [
    "$GPGGA,123519,4807.038,N,01131.000,E,1,08,0.9,545.4,M,46.9,M,,*47",
    "$GPRMC,123520,A,4807.038,N,01131.000,E,022.4,084.4,230394,003.1,W*6A"
]

def parse_gps_data(nmea_sentences):
    for sentence in nmea_sentences:
        try:
            msg = pynmea2.parse(sentence)
            print(f"Sentence Type: {msg.sentence_type}")

            if isinstance(msg, pynmea2.types.talker.GGA):  # Position fix data
                print(f"Time (UTC): {msg.timestamp}")
                print(f"Latitude: {msg.latitude} {msg.lat_dir}")
                print(f"Longitude: {msg.longitude} {msg.lon_dir}")
                print(f"Fix Quality: {msg.gps_qual}")
                print(f"Number of Satellites: {msg.num_sats}")
                print(f"Altitude: {msg.altitude} {msg.altitude_units}")

            elif isinstance(msg, pynmea2.types.talker.RMC):  # Recommended minimum data
                print(f"Date: {msg.datestamp}")
                print(f"Time (UTC): {msg.timestamp}")
                print(f"Latitude: {msg.latitude} {msg.lat_dir}")
                print(f"Longitude: {msg.longitude} {msg.lon_dir}")
                print(f"Speed over ground (knots): {msg.spd_over_grnd}")
                print(f"Track angle: {msg.true_course}")
        except pynmea2.ParseError as e:
            print(f"Failed to parse sentence: {e}")

# Run the parser
parse_gps_data(sample_sentences)
